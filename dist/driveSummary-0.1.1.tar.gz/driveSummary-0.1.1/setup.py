# from distutils.core import setup
from setuptools import setup, find_packages
setup(
    name='driveSummary',
    version='0.1.1',
    url='https://github.com/cavpp/drive_summary',
    license='GPL',
    author='Henry Borchers',
    author_email='hborcher@berkeley.edu',
    description='Written for the California AV Preservation Project, Utility to get a summary of the AV files on a '
                'given drive or folder',
    include_package_data=True,
    entry_points={'console_scripts': ['driveSummary = bin.driveSummaryCLI:main', 'driveSummarygui = bin.driveSummaryGUI:main']},
    packages=find_packages(),
    install_requires=['pip >= 6.0',
                      'setuptools >= 11.3',
                      'PySide >= 1.2.2']
)
